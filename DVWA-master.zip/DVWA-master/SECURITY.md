The clue is in its name, DVWA contains both intentional and unintentional vulnerabliities, that is it's whole point, please do not try to report them.
